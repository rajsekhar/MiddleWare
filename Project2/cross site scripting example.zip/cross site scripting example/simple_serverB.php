<?php 
 

  print "<p>stuff from other server</p> ";
?>
