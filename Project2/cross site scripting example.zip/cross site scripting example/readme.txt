Bring up simpleQ.html in a web server (apache, IIS, etc.)

Access simpleQ.html with either Firefox or Edge (Chrome will stop this particular attack)

Copy and paste from myhack.txt into the data input area in simpleQ.html

You will see that data from a totally different web page is downloaded.